/* MEYAR: متابعة التعلّم محلياً على هذا الجهاز */
(function () {
  const LESSONS_KEY = 'meyar_completed_lessons_v1';
  const QUIZ_KEY = 'meyar_quiz_best_v1';

  function read(key, fallback) {
    try {
      const value = localStorage.getItem(key);
      return value ? JSON.parse(value) : fallback;
    } catch (_) {
      return fallback;
    }
  }

  function write(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch (_) {
      return false;
    }
  }

  function getCompletedLessons() {
    const value = read(LESSONS_KEY, []);
    return Array.isArray(value) ? value.map(Number).filter(n => n >= 1 && n <= 5) : [];
  }

  function completeLesson(number) {
    const lesson = Number(number);
    if (!Number.isInteger(lesson) || lesson < 1 || lesson > 5) return false;
    const completed = getCompletedLessons();
    if (!completed.includes(lesson)) completed.push(lesson);
    return write(LESSONS_KEY, completed.sort((a, b) => a - b));
  }

  function saveQuizScore(score, total) {
    const current = read(QUIZ_KEY, { best: 0, last: 0, total: Number(total) || 0 });
    const safeScore = Math.max(0, Number(score) || 0);
    const safeTotal = Math.max(1, Number(total) || 1);
    const best = Math.max(Number(current.best) || 0, safeScore);
    return write(QUIZ_KEY, { best, last: safeScore, total: safeTotal, updatedAt: new Date().toISOString() });
  }

  function getQuizScore() {
    return read(QUIZ_KEY, null);
  }

  function renderBasicsProgress() {
    const root = document.getElementById('meyar-progress-summary');
    if (!root) return;
    const completed = getCompletedLessons();
    const percent = Math.round((completed.length / 5) * 100);
    root.innerHTML = `
      <div class="progress-summary-head"><strong>تقدمك في مسار الأساسيات</strong><b>${percent}%</b></div>
      <div class="progress"><span style="width:${percent}%"></span></div>
      <p class="muted">أكملت ${completed.length} من 5 دروس. يُحفظ تقدمك على هذا الجهاز والمتصفح.</p>`;
    document.querySelectorAll('[data-lesson]').forEach(row => {
      const number = Number(row.getAttribute('data-lesson'));
      const title = row.querySelector('b');
      if (!title) return;
      let status = row.querySelector('.lesson-status');
      if (!status) {
        status = document.createElement('span');
        status.className = 'lesson-status';
        title.insertAdjacentElement('afterend', status);
      }
      status.textContent = completed.includes(number) ? '✓ مكتمل' : 'لم يكتمل بعد';
      status.classList.toggle('is-complete', completed.includes(number));
    });
  }

  window.MeyarProgress = { getCompletedLessons, completeLesson, saveQuizScore, getQuizScore, renderBasicsProgress };
})();
